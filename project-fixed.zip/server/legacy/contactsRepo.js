const { getPool, sql } = require('./db');

// بيدور على الكونتاكت اللي رقم التليفون ده مرتبط بيه (لو موجود)
async function findContactByPhone(phoneNumber) {
  const pool = await getPool();
  const result = await pool
    .request()
    .input('phone', sql.NVarChar(30), phoneNumber)
    .query(`
      SELECT c.*
      FROM [dbo].[NileChat_Contacts_byA] c
      INNER JOIN [dbo].[NileChat_ContactPhones_byA] p ON p.contact_id = c.id
      WHERE p.phone_number = @phone
    `);
  return result.recordset[0] || null;
}

// بينشئ كونتاكت جديد ويربطه فورًا برقم التليفون اللي بعت بيه
async function createContactWithPhone(name, phoneNumber) {
  const pool = await getPool();
  const result = await pool
    .request()
    .input('name', sql.NVarChar(200), name || phoneNumber)
    .query(`
      INSERT INTO [dbo].[NileChat_Contacts_byA] (name)
      OUTPUT INSERTED.*
      VALUES (@name)
    `);
  const contact = result.recordset[0];

  await pool
    .request()
    .input('contactId', sql.BigInt, contact.id)
    .input('phone', sql.NVarChar(30), phoneNumber)
    .query(`
      INSERT INTO [dbo].[NileChat_ContactPhones_byA] (contact_id, phone_number)
      VALUES (@contactId, @phone)
    `);

  return contact;
}

async function getContactById(id) {
  const pool = await getPool();
  const result = await pool
    .request()
    .input('id', sql.BigInt, id)
    .query(`SELECT * FROM [dbo].[NileChat_Contacts_byA] WHERE id = @id`);
  return result.recordset[0] || null;
}

async function getPhonesForContact(contactId) {
  const pool = await getPool();
  const result = await pool
    .request()
    .input('contactId', sql.BigInt, contactId)
    .query(`
      SELECT phone_number FROM [dbo].[NileChat_ContactPhones_byA]
      WHERE contact_id = @contactId
      ORDER BY created_at ASC
    `);
  return result.recordset.map((r) => r.phone_number);
}

async function getContactByIdWithPhones(id) {
  const contact = await getContactById(id);
  if (!contact) return null;
  const phones = await getPhonesForContact(id);
  return { ...contact, phones };
}

// كل الكونتاكتس (تُستخدم في صفحة Contacts وفي قايمة اختيار "اربط بكونتاكت موجود")
async function listContacts() {
  const pool = await getPool();
  const contactsResult = await pool
    .request()
    .query(`SELECT id, name, created_at FROM [dbo].[NileChat_Contacts_byA] ORDER BY name ASC`);
  const phonesResult = await pool
    .request()
    .query(`SELECT contact_id, phone_number FROM [dbo].[NileChat_ContactPhones_byA] ORDER BY created_at ASC`);

  const phonesByContact = {};
  for (const row of phonesResult.recordset) {
    if (!phonesByContact[row.contact_id]) phonesByContact[row.contact_id] = [];
    phonesByContact[row.contact_id].push(row.phone_number);
  }

  return contactsResult.recordset.map((c) => ({ ...c, phones: phonesByContact[c.id] || [] }));
}

async function updateContactName(id, name) {
  const pool = await getPool();
  const result = await pool
    .request()
    .input('id', sql.BigInt, id)
    .input('name', sql.NVarChar(200), name)
    .query(`
      UPDATE [dbo].[NileChat_Contacts_byA]
      SET name = @name
      OUTPUT INSERTED.*
      WHERE id = @id
    `);
  return result.recordset[0] || null;
}

// بينقل رقم تليفون عشان ينضم لكونتاكت تاني (دمج): لو الرقم متسجل قبل كده بيتحرك،
// ولو لأ بيتسجل جديد على الكونتاكت المطلوب
async function linkPhoneToContact(phoneNumber, contactId) {
  const pool = await getPool();
  const existing = await pool
    .request()
    .input('phone', sql.NVarChar(30), phoneNumber)
    .query(`SELECT id FROM [dbo].[NileChat_ContactPhones_byA] WHERE phone_number = @phone`);

  if (existing.recordset.length > 0) {
    await pool
      .request()
      .input('phone', sql.NVarChar(30), phoneNumber)
      .input('contactId', sql.BigInt, contactId)
      .query(`UPDATE [dbo].[NileChat_ContactPhones_byA] SET contact_id = @contactId WHERE phone_number = @phone`);
  } else {
    await pool
      .request()
      .input('phone', sql.NVarChar(30), phoneNumber)
      .input('contactId', sql.BigInt, contactId)
      .query(`INSERT INTO [dbo].[NileChat_ContactPhones_byA] (contact_id, phone_number) VALUES (@contactId, @phone)`);
  }
}

// لو كونتاكت بقى من غير أي رقم بعد الدمج (كل أرقامه اتنقلت لكونتاكت تاني)، نشيله عشان
// مايفضلش يظهر فاضي في صفحة الكونتاكتس
async function deletePhonelessContact(contactId) {
  const pool = await getPool();
  const phones = await getPhonesForContact(contactId);
  if (phones.length > 0) return false;
  await pool.request().input('id', sql.BigInt, contactId).query(`DELETE FROM [dbo].[NileChat_Contacts_byA] WHERE id = @id`);
  return true;
}

module.exports = {
  findContactByPhone,
  createContactWithPhone,
  getContactById,
  getContactByIdWithPhones,
  getPhonesForContact,
  listContacts,
  updateContactName,
  linkPhoneToContact,
  deletePhonelessContact,
};
